package com.micropassos.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.BarChart
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Night = Color(0xFF10111B)
private val Panel = Color(0xFF1C1D2B)
private val Violet = Color(0xFF8B5CF6)
private val Lavender = Color(0xFFB9A0FF)
private val Mint = Color(0xFF35D399)
private val SoftWhite = Color(0xFFF5F3FF)
private val Muted = Color(0xFFA7A5B5)

data class StepTask(val id: Long, val title: String, val done: Boolean = false)
data class Journey(val id: Long, val title: String, val tasks: List<StepTask>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MicroPassosTheme { MicroPassosApp(this) } }
    }
}

@Composable
private fun MicroPassosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            secondary = Lavender,
            background = Night,
            surface = Panel,
            onBackground = SoftWhite,
            onSurface = SoftWhite
        ),
        content = content
    )
}

@Composable
private fun MicroPassosApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("micropassos", Context.MODE_PRIVATE) }
    var journeys by remember { mutableStateOf(loadJourneys(prefs)) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 1)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreate by remember { mutableStateOf(false) }
    var goalText by remember { mutableStateOf("") }
    var showCelebration by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(prefs.getString("profile_name", "Explorador") ?: "Explorador") }
    var avatar by remember { mutableStateOf(prefs.getString("avatar", "🌱") ?: "🌱") }
    var detail by remember { mutableStateOf("") }
    var dates by remember { mutableStateOf(prefs.getString("active_dates", "")!!.split(",").filter { it.isNotBlank() }.toSet()) }
    fun today(): String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    fun complete(journeyId: Long, taskId: Long) {
        if (journeys.none { j -> j.id == journeyId && j.tasks.any { it.id == taskId && !it.done } }) return
        journeys = journeys.map { j -> if (j.id == journeyId) j.copy(tasks = j.tasks.map { t -> if (t.id == taskId) t.copy(done = true) else t }) else j }
        xp += 10
        dates = dates + today()
        streak = 0
        val cal = java.util.Calendar.getInstance()
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        while (fmt.format(cal.time) in dates) { streak++; cal.add(java.util.Calendar.DAY_OF_YEAR, -1) }
        saveJourneys(prefs, journeys)
        prefs.edit().putInt("xp", xp).putInt("streak", streak).putString("active_dates", dates.joinToString(",")).apply()
        showCelebration = true
    }

    fun persist() {
        saveJourneys(prefs, journeys)
        prefs.edit().putInt("xp", xp).putInt("streak", streak).apply()
    }

    val totalTasks = journeys.sumOf { it.tasks.size }
    val doneTasks = journeys.sumOf { j -> j.tasks.count { it.done } }
    val level = xp / 100 + 1
    val levelXp = xp % 100

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = SoftWhite) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Image(painterResource(R.drawable.nav_home), null, modifier = Modifier.size(30.dp)) }, label = { Text("Início") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Image(painterResource(R.drawable.nav_journeys), null, modifier = Modifier.size(30.dp)) }, label = { Text("Jornadas") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Image(painterResource(R.drawable.nav_discover), null, modifier = Modifier.size(30.dp)) }, label = { Text("Descubra", fontSize = 10.sp) })
                NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 }, icon = { Image(painterResource(R.drawable.nav_analysis), null, modifier = Modifier.size(30.dp)) }, label = { Text("Análise", fontSize = 10.sp) })
                NavigationBarItem(selected = selectedTab == 4, onClick = { selectedTab = 4 }, icon = { Image(painterResource(R.drawable.nav_profile), null, modifier = Modifier.size(30.dp)) }, label = { Text("Perfil", fontSize = 10.sp) })
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Text("MICROPASSOS  ✦", color = Lavender, letterSpacing = 2.sp); Text("Seu mundo, $name", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                item { UniverseCard(doneTasks, xp) { detail = it } }
                item { Text("Nível $level  •  $xp XP", color = Lavender); LinearProgressIndicator(progress = { levelXp / 100f }, modifier = Modifier.fillMaxWidth(), color = Violet) }
                item {
                    val next = journeys.firstOrNull { j -> j.tasks.any { !it.done } }
                    val task = next?.tasks?.firstOrNull { !it.done }
                    Text("Próximo pequeno passo", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (next != null && task != null) {
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(next.title, color = Lavender); Text(task.title); Button(onClick = { complete(next.id, task.id) }) { Text("Concluir • +10 cristais") } } }
                    } else Button(onClick = { showCreate = true }) { Text("Criar jornada") }
                }
                item { Text("$doneTasks de $totalTasks passos concluídos", color = Muted); OutlinedButton(onClick = { selectedTab = 1 }) { Text("Ver minhas jornadas") } }
            }
            1 -> JourneysScreen(padding, journeys, { showCreate = true }, ::complete)
            2 -> DiscoverScreen(padding) { title, tasks ->
                if (journeys.none { it.title == title }) { val id = System.currentTimeMillis(); journeys = journeys + Journey(id, title, tasks.mapIndexed { i, t -> StepTask(id + i + 1, t) }); persist() }
                selectedTab = 1
            }
            3 -> AnalysisScreen(padding, journeys, xp, dates)
            4 -> LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Meu perfil", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text(avatar, fontSize = 48.sp) }
                item { Row { listOf("🌱", "🦊", "🌙", "🚀").forEach { a -> TextButton(onClick = { avatar = a; prefs.edit().putString("avatar", a).apply() }) { Text(a, fontSize = 23.sp) } } } }
                item { OutlinedTextField(value = name, onValueChange = { name = it.take(30); prefs.edit().putString("profile_name", name).apply() }, label = { Text("Seu nome") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item { StatTile("✨", "Experiência", "$xp XP • Nível $level"); StatTile("💎", "Cristais conquistados", "${doneTasks * 10}"); StatTile("📅", "Dias registrados", "${dates.size}") }
                item { Text("Medalhas", fontSize = 20.sp); Achievement("🌱", "Primeiro passo", "Conclua uma missão", doneTasks >= 1); Achievement("⭐", "Dez passos", "Conclua 10 missões", doneTasks >= 10); Achievement("🏆", "Centenário", "Acumule 100 XP", xp >= 100) }
            }
        }
    }
    if (detail.isNotEmpty()) AlertDialog(onDismissRequest = { detail = "" }, title = { Text("Seu universo") }, text = { Text(detail) }, confirmButton = { TextButton(onClick = { detail = "" }) { Text("Fechar") } })

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Nova jornada", color = SoftWhite) },
            text = {
                Column {
                    Text("Qual objetivo você quer alcançar?", color = Muted)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = goalText, onValueChange = { goalText = it }, placeholder = { Text("Ex.: aprender inglês") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val title = goalText.trim()
                    if (title.isNotEmpty()) {
                        val id = System.currentTimeMillis()
                        journeys = journeys + Journey(id, title, starterTasks(title, id))
                        goalText = ""
                        showCreate = false
                        persist()
                    }
                }) { Text("Criar jornada", color = Lavender) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancelar") } },
            containerColor = Panel
        )
    }

    if (showCelebration) {
        AlertDialog(
            onDismissRequest = { showCelebration = false },
            title = { Text("Pequena vitória! ✨", color = SoftWhite) },
            text = { Text("Você ganhou 10 XP e 10 cristais. Seu universo está crescendo!", color = Muted) },
            confirmButton = { TextButton(onClick = { showCelebration = false }) { Text("Continuar", color = Lavender) } },
            containerColor = Panel
        )
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues, xp: Int, level: Int, levelXp: Int, streak: Int,
    done: Int, total: Int, journeys: List<Journey>, onCreate: () -> Unit,
    onComplete: (Long, Long) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("MICROPASSOS  ✦", color = Lavender, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text("Cada passo\nconta.", color = SoftWhite, fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
            Text("Um pouco hoje já é progresso.", color = Muted, fontSize = 14.sp)
        }
        item { LevelCard(level, xp, levelXp, streak) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Sua evolução", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("$done/$total passos", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = Mint, trackColor = Panel)
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Missões para avançar", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onCreate) { Text("+ Nova", color = Lavender) }
            }
        }
        if (journeys.isEmpty()) {
            item { EmptyState(onCreate) }
        } else {
            items(journeys, key = { it.id }) { journey -> JourneyCard(journey, onComplete) }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
private fun LevelCard(level: Int, xp: Int, levelXp: Int, streak: Int) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("SEU NÍVEL", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text("Explorador $level", color = SoftWhite, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(Violet.copy(alpha = .2f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Lightbulb, null, tint = Lavender, modifier = Modifier.size(26.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("$xp XP", color = Lavender, fontWeight = FontWeight.SemiBold)
                Text("${100 - levelXp} XP para o próximo nível", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { levelXp / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = Violet, trackColor = Night)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Whatshot, null, tint = Color(0xFFFFA45B), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("$streak dia(s) de sequência", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun JourneyCard(journey: Journey, onComplete: (Long, Long) -> Unit) {
    val done = journey.tasks.count { it.done }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(journey.title, color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("$done de ${journey.tasks.size} passos concluídos", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(9.dp))
            LinearProgressIndicator(progress = { if (journey.tasks.isEmpty()) 0f else done.toFloat() / journey.tasks.size }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Mint, trackColor = Night)
            Spacer(Modifier.height(10.dp))
            journey.tasks.forEach { task ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(task.title, color = if (task.done) Muted else SoftWhite, fontSize = 13.sp)
                        if (task.done) Text("Concluído", color = Mint, fontSize = 10.sp)
                    }
                    if (!task.done) {
                        TextButton(onClick = { onComplete(journey.id, task.id) }) {
                            Text("Concluir +10 XP", color = Lavender, fontSize = 11.sp)
                        }
                    } else {
                        Text("✓", color = Mint, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(onCreate: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🌱", fontSize = 32.sp)
            Spacer(Modifier.height(8.dp))
            Text("Toda conquista começa aqui", color = SoftWhite, fontWeight = FontWeight.Bold)
            Text("Crie seu primeiro objetivo e dê o primeiro passo.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Criar minha jornada") }
        }
    }
}

@Composable
private fun JourneysScreen(padding: PaddingValues, journeys: List<Journey>, onCreate: () -> Unit, onComplete: (Long, Long) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Minhas jornadas", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Objetivos divididos em passos possíveis.", color = Muted, fontSize = 13.sp)
        Button(onClick = onCreate) { Text("+ Nova jornada") }
        Spacer(Modifier.height(16.dp))
        if (journeys.isEmpty()) EmptyState(onCreate) else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(journeys, key = { it.id }) { JourneyCard(it, onComplete) } }
    }
}

@Composable
private fun AchievementsScreen(padding: PaddingValues, xp: Int, level: Int, streak: Int, done: Int) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Conquistas", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Cada pequeno avanço merece reconhecimento.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        StatTile("🏅", "Nível alcançado", "Explorador $level")
        StatTile("✨", "Experiência acumulada", "$xp XP")
        StatTile("🎯", "Passos concluídos", "$done missões")
        StatTile("🔥", "Sequência atual", "$streak dia(s)")
        Spacer(Modifier.height(12.dp))
        Text("Medalhas", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Achievement("🌱", "Primeiro passo", "Conclua sua primeira missão", done >= 1)
        Achievement("⭐", "Dez passos", "Conclua 10 missões", done >= 10)
        Achievement("🏆", "Centenário", "Acumule 100 XP", xp >= 100)
    }
}

@Composable
private fun StatTile(emoji: String, title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 23.sp)
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Muted, fontSize = 11.sp); Text(value, color = SoftWhite, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun Achievement(emoji: String, title: String, description: String, unlocked: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(if (unlocked) Violet.copy(alpha = .2f) else Panel), contentAlignment = Alignment.Center) { Text(if (unlocked) emoji else "🔒", fontSize = 20.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, color = if (unlocked) SoftWhite else Muted, fontWeight = FontWeight.SemiBold); Text(description, color = Muted, fontSize = 11.sp) }
        if (unlocked) Text("Desbloqueada", color = Mint, fontSize = 10.sp)
    }
}

private fun starterTasks(title: String, journeyId: Long): List<StepTask> = listOf(
    StepTask(journeyId + 1, "Pesquisar o primeiro passo para: $title"),
    StepTask(journeyId + 2, "Reservar 10 minutos para começar"),
    StepTask(journeyId + 3, "Praticar e registrar o que aprendeu")
)

private fun loadJourneys(prefs: android.content.SharedPreferences): List<Journey> {
    val raw = prefs.getString("journeys", null) ?: return listOf(
        Journey(1L, "Aprender programação", listOf(
            StepTask(2L, "Pesquisar linguagens de programação"),
            StepTask(3L, "Conhecer o Android Studio"),
            StepTask(4L, "Criar meu primeiro aplicativo")
        ))
    )
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            val taskArray = obj.getJSONArray("tasks")
            val tasks = (0 until taskArray.length()).map { j ->
                val task = taskArray.getJSONObject(j)
                StepTask(task.getLong("id"), task.getString("title"), task.getBoolean("done"))
            }
            Journey(obj.getLong("id"), obj.getString("title"), tasks)
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveJourneys(prefs: android.content.SharedPreferences, journeys: List<Journey>) {
    val array = JSONArray()
    journeys.forEach { journey ->
        val obj = JSONObject().put("id", journey.id).put("title", journey.title)
        val tasks = JSONArray()
        journey.tasks.forEach { task -> tasks.put(JSONObject().put("id", task.id).put("title", task.title).put("done", task.done)) }
        obj.put("tasks", tasks)
        array.put(obj)
    }
    prefs.edit().putString("journeys", array.toString()).apply()
}

@Composable
private fun UniverseCard(done: Int, xp: Int, onDetail: (String) -> Unit) {
    val thresholds = listOf(1, 3, 5, 10, 15)
    val names = listOf("Árvore lunar", "Casa estelar", "Lago mágico", "Cristais gigantes", "Estrela guardiã")
    val unlocked = thresholds.count { done >= it }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("MEU UNIVERSO", color = Lavender, fontWeight = FontWeight.Bold); Text("💎 ${done * 10}") }
            Box(Modifier.fillMaxWidth().height(220.dp)) {
            Canvas(Modifier.matchParentSize()) {
                val w = size.width; val h = size.height
                fun pt(x: Float, y: Float) = Offset(x*w,y*h)
                fun poly(color: Color, vararg points: Pair<Float,Float>) { val p = Path(); points.forEachIndexed { i, v -> if(i==0) p.moveTo(v.first*w,v.second*h) else p.lineTo(v.first*w,v.second*h) }; p.close(); drawPath(p,color) }
                drawRect(Brush.verticalGradient(listOf(Color(0xFF252044), Night)))
                repeat(45) { i -> drawCircle(Lavender.copy(alpha=.55f), if(i%7==0) 2.5f else 1.2f, pt(((i*73+17)%101)/101f, ((i*43+9)%97)/97f)) }
                poly(Color(0xFF59446E), .12f to .56f,.88f to .56f,.70f to .79f,.49f to .94f,.29f to .79f)
                poly(Color(0xFF403151), .49f to .94f,.55f to .64f,.88f to .56f,.70f to .79f)
                drawOval(Color(0xFF457B65), pt(.10f,.39f), Size(w*.80f,h*.30f))
                drawOval(Color(0xFF75A88A), pt(.10f,.36f), Size(w*.80f,h*.29f))
            }
            val art = listOf(R.drawable.world_tree, R.drawable.world_house, R.drawable.world_pond, R.drawable.world_crystal, R.drawable.world_star)
            val positions = listOf(Alignment.CenterStart, Alignment.TopCenter, Alignment.CenterEnd, Alignment.BottomStart, Alignment.TopEnd)
            art.forEachIndexed { i, res ->
                if (done >= thresholds[i]) Image(painterResource(res), names[i], modifier = Modifier.align(positions[i]).padding(8.dp).size(if(i==4) 65.dp else 100.dp).clickable { onDetail(names[i] + ": desbloqueado!") }, contentScale = ContentScale.Fit)
            }
            }
            Text("$unlocked de 5 elementos desbloqueados", color = Lavender)
            LinearProgressIndicator(progress = { unlocked / 5f }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Mint)
            Text(if(unlocked == 5) "Seu universo está completo!" else "Próximo: ${names[unlocked]} • ${thresholds[unlocked] - done} passos", color = Muted)
            thresholds.forEachIndexed { i, n -> TextButton(onClick = { onDetail("${names[i]}: ${if(done>=n) "desbloqueado!" else "conclua $n passos para desbloquear."}") }, modifier = Modifier.fillMaxWidth()) { Text("${if(done>=n) "✓" else "🔒"} ${names[i]}") } }
        }
    }
}
@Composable
private fun DiscoverScreen(padding: PaddingValues, onAdd: (String,List<String>) -> Unit) {
    val templates = listOf("Ler mais" to listOf("Escolher um livro", "Ler 5 minutos", "Anotar uma ideia"), "Organizar minha rotina" to listOf("Listar três prioridades", "Organizar a mesa", "Planejar amanhã"), "Aprender inglês" to listOf("Escolher cinco palavras", "Ouvir uma frase", "Praticar por 5 minutos"), "Criar um projeto" to listOf("Escrever a ideia", "Definir um pequeno objetivo", "Criar um rascunho"))
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Descubra", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Uma nova aventura começa aqui.", color = Muted) }
        items(templates) { (title,tasks) -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold); tasks.forEach { Text("• $it", color = Muted) }; Button(onClick = { onAdd(title,tasks) }) { Text("Começar jornada") } } } }
    }
}
@Composable
private fun AnalysisScreen(padding: PaddingValues, journeys: List<Journey>, xp: Int, dates: Set<String>) {
    val total = journeys.sumOf { it.tasks.size }; val done = journeys.sumOf { j -> j.tasks.count { it.done } }
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Sua evolução", fontSize = 27.sp, fontWeight = FontWeight.Bold); StatTile("🎯", "Taxa de conclusão", "${if(total==0) 0 else done*100/total}%"); StatTile("✨", "XP total", "$xp"); StatTile("📅", "Dias ativos registrados", "${dates.size}"); Text("Progresso por jornada", fontWeight = FontWeight.Bold) }
        items(journeys) { j -> val d = j.tasks.count { it.done }; Text("${j.title} • $d/${j.tasks.size}"); LinearProgressIndicator(progress = { if(j.tasks.isEmpty()) 0f else d.toFloat()/j.tasks.size }, modifier = Modifier.fillMaxWidth(), color = Mint) }
        item { Text("Atividade nos últimos 7 dias", fontWeight = FontWeight.Bold); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US); for(i in 6 downTo 0) { val c = java.util.Calendar.getInstance(); c.add(java.util.Calendar.DAY_OF_YEAR,-i); val active = fmt.format(c.time) in dates; Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(30.dp).clip(CircleShape).background(if(active) Violet else Panel)); Text("${c.get(java.util.Calendar.DAY_OF_MONTH)}", color = Muted) } } }; Text("Histórico de atividade começa nesta versão.", color = Muted, fontSize = 12.sp) }
    }
}
