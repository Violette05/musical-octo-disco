package com.micropassos.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Night = Color(0xFF10111B)
private val Panel = Color(0xFF1C1D2B)
private val Violet = Color(0xFF8B5CF6)
private val Lavender = Color(0xFFB9A0FF)
private val Mint = Color(0xFF35D399)
private val SoftWhite = Color(0xFFF5F3FF)
private val Muted = Color(0xFFA7A5B5)

data class StepTask(val id: Long, val title: String, val done: Boolean = false)
data class Journey(val id: Long, val title: String, val tasks: List<StepTask>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MicroPassosTheme { MicroPassosApp(this) } }
    }
}

@Composable
private fun MicroPassosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            secondary = Lavender,
            background = Night,
            surface = Panel,
            onBackground = SoftWhite,
            onSurface = SoftWhite
        ),
        content = content
    )
}

@Composable
private fun MicroPassosApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("micropassos", Context.MODE_PRIVATE) }
    var journeys by remember { mutableStateOf(loadJourneys(prefs)) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 1)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreate by remember { mutableStateOf(false) }
    var goalText by remember { mutableStateOf("") }
    var showCelebration by remember { mutableStateOf(false) }

    fun persist() {
        saveJourneys(prefs, journeys)
        prefs.edit().putInt("xp", xp).putInt("streak", streak).apply()
    }

    val totalTasks = journeys.sumOf { it.tasks.size }
    val doneTasks = journeys.sumOf { j -> j.tasks.count { it.done } }
    val level = xp / 100 + 1
    val levelXp = xp % 100

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = SoftWhite) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Flag, null) }, label = { Text("Jornadas") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.EmojiEvents, null) }, label = { Text("Conquistas") })
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }, containerColor = Violet, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Criar jornada")
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> HomeScreen(
                padding, xp, level, levelXp, streak, doneTasks, totalTasks, journeys,
                onCreate = { showCreate = true },
                onComplete = { journeyId, taskId ->
                    val journey = journeys.firstOrNull { it.id == journeyId }
                    val task = journey?.tasks?.firstOrNull { it.id == taskId }
                    if (task != null && !task.done) {
                        journeys = journeys.map { j ->
                            if (j.id == journeyId) j.copy(tasks = j.tasks.map { t -> if (t.id == taskId) t.copy(done = true) else t }) else j
                        }
                        xp += 10
                        persist()
                        showCelebration = true
                    }
                }
            )
            1 -> JourneysScreen(padding, journeys, onCreate = { showCreate = true }, onComplete = { journeyId, taskId ->
                journeys = journeys.map { j -> if (j.id == journeyId) j.copy(tasks = j.tasks.map { t -> if (t.id == taskId && !t.done) { xp += 10; t.copy(done = true) } else t }) else j }
                persist()
            })
            else -> AchievementsScreen(padding, xp, level, streak, doneTasks)
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Nova jornada", color = SoftWhite) },
            text = {
                Column {
                    Text("Qual objetivo você quer alcançar?", color = Muted)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = goalText, onValueChange = { goalText = it }, placeholder = { Text("Ex.: aprender inglês") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val title = goalText.trim()
                    if (title.isNotEmpty()) {
                        val id = System.currentTimeMillis()
                        journeys = journeys + Journey(id, title, starterTasks(title, id))
                        goalText = ""
                        showCreate = false
                        persist()
                    }
                }) { Text("Criar jornada", color = Lavender) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancelar") } },
            containerColor = Panel
        )
    }

    if (showCelebration) {
        AlertDialog(
            onDismissRequest = { showCelebration = false },
            title = { Text("Pequena vitória! ✨", color = SoftWhite) },
            text = { Text("Você ganhou 10 XP. Cada passo conta!", color = Muted) },
            confirmButton = { TextButton(onClick = { showCelebration = false }) { Text("Continuar", color = Lavender) } },
            containerColor = Panel
        )
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues, xp: Int, level: Int, levelXp: Int, streak: Int,
    done: Int, total: Int, journeys: List<Journey>, onCreate: () -> Unit,
    onComplete: (Long, Long) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("MICROPASSOS  ✦", color = Lavender, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text("Cada passo\nconta.", color = SoftWhite, fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
            Text("Um pouco hoje já é progresso.", color = Muted, fontSize = 14.sp)
        }
        item { LevelCard(level, xp, levelXp, streak) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Sua evolução", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("$done/$total passos", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = Mint, trackColor = Panel)
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Missões para avançar", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onCreate) { Text("+ Nova", color = Lavender) }
            }
        }
        if (journeys.isEmpty()) {
            item { EmptyState(onCreate) }
        } else {
            items(journeys, key = { it.id }) { journey -> JourneyCard(journey, onComplete) }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
private fun LevelCard(level: Int, xp: Int, levelXp: Int, streak: Int) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("SEU NÍVEL", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text("Explorador $level", color = SoftWhite, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(Violet.copy(alpha = .2f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Lightbulb, null, tint = Lavender, modifier = Modifier.size(26.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("$xp XP", color = Lavender, fontWeight = FontWeight.SemiBold)
                Text("${100 - levelXp} XP para o próximo nível", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { levelXp / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = Violet, trackColor = Night)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Whatshot, null, tint = Color(0xFFFFA45B), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("$streak dia(s) de sequência", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun JourneyCard(journey: Journey, onComplete: (Long, Long) -> Unit) {
    val done = journey.tasks.count { it.done }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(journey.title, color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("$done de ${journey.tasks.size} passos concluídos", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(9.dp))
            LinearProgressIndicator(progress = { if (journey.tasks.isEmpty()) 0f else done.toFloat() / journey.tasks.size }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Mint, trackColor = Night)
            Spacer(Modifier.height(10.dp))
            journey.tasks.forEach { task ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(task.title, color = if (task.done) Muted else SoftWhite, fontSize = 13.sp)
                        if (task.done) Text("Concluído", color = Mint, fontSize = 10.sp)
                    }
                    if (!task.done) {
                        TextButton(onClick = { onComplete(journey.id, task.id) }) {
                            Text("Concluir +10 XP", color = Lavender, fontSize = 11.sp)
                        }
                    } else {
                        Text("✓", color = Mint, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(onCreate: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🌱", fontSize = 32.sp)
            Spacer(Modifier.height(8.dp))
            Text("Toda conquista começa aqui", color = SoftWhite, fontWeight = FontWeight.Bold)
            Text("Crie seu primeiro objetivo e dê o primeiro passo.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Criar minha jornada") }
        }
    }
}

@Composable
private fun JourneysScreen(padding: PaddingValues, journeys: List<Journey>, onCreate: () -> Unit, onComplete: (Long, Long) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Minhas jornadas", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Objetivos divididos em passos possíveis.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        if (journeys.isEmpty()) EmptyState(onCreate) else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) { items(journeys, key = { it.id }) { JourneyCard(it, onComplete) } }
    }
}

@Composable
private fun AchievementsScreen(padding: PaddingValues, xp: Int, level: Int, streak: Int, done: Int) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Conquistas", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Cada pequeno avanço merece reconhecimento.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        StatTile("🏅", "Nível alcançado", "Explorador $level")
        StatTile("✨", "Experiência acumulada", "$xp XP")
        StatTile("🎯", "Passos concluídos", "$done missões")
        StatTile("🔥", "Sequência atual", "$streak dia(s)")
        Spacer(Modifier.height(12.dp))
        Text("Medalhas", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Achievement("🌱", "Primeiro passo", "Conclua sua primeira missão", done >= 1)
        Achievement("⭐", "Dez passos", "Conclua 10 missões", done >= 10)
        Achievement("🏆", "Centenário", "Acumule 100 XP", xp >= 100)
    }
}

@Composable
private fun StatTile(emoji: String, title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 23.sp)
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Muted, fontSize = 11.sp); Text(value, color = SoftWhite, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun Achievement(emoji: String, title: String, description: String, unlocked: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(if (unlocked) Violet.copy(alpha = .2f) else Panel), contentAlignment = Alignment.Center) { Text(if (unlocked) emoji else "🔒", fontSize = 20.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, color = if (unlocked) SoftWhite else Muted, fontWeight = FontWeight.SemiBold); Text(description, color = Muted, fontSize = 11.sp) }
        if (unlocked) Text("Desbloqueada", color = Mint, fontSize = 10.sp)
    }
}

private fun starterTasks(title: String, journeyId: Long): List<StepTask> = listOf(
    StepTask(journeyId + 1, "Pesquisar o primeiro passo para: $title"),
    StepTask(journeyId + 2, "Reservar 10 minutos para começar"),
    StepTask(journeyId + 3, "Praticar e registrar o que aprendeu")
)

private fun loadJourneys(prefs: android.content.SharedPreferences): List<Journey> {
    val raw = prefs.getString("journeys", null) ?: return listOf(
        Journey(1L, "Aprender programação", listOf(
            StepTask(2L, "Pesquisar linguagens de programação"),
            StepTask(3L, "Conhecer o Android Studio"),
            StepTask(4L, "Criar meu primeiro aplicativo")
        ))
    )
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            val taskArray = obj.getJSONArray("tasks")
            val tasks = (0 until taskArray.length()).map { j ->
                val task = taskArray.getJSONObject(j)
                StepTask(task.getLong("id"), task.getString("title"), task.getBoolean("done"))
            }
            Journey(obj.getLong("id"), obj.getString("title"), tasks)
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveJourneys(prefs: android.content.SharedPreferences, journeys: List<Journey>) {
    val array = JSONArray()
    journeys.forEach { journey ->
        val obj = JSONObject().put("id", journey.id).put("title", journey.title)
        val tasks = JSONArray()
        journey.tasks.forEach { task -> tasks.put(JSONObject().put("id", task.id).put("title", task.title).put("done", task.done)) }
        obj.put("tasks", tasks)
        array.put(obj)
    }
    prefs.edit().putString("journeys", array.toString()).apply()
}
